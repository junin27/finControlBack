package fincontrol.com.fincontrol.model.enums;

public enum ReceivableStatus {

    PENDING,
    RECEIVED,
    LATE

}
