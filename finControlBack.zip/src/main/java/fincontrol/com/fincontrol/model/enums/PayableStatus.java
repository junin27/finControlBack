package fincontrol.com.fincontrol.model.enums;

public enum PayableStatus {

    PENDING,
    PAID,
    OVERDUE

}
